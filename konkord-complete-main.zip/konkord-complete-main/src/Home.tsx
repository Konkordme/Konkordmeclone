import { useCallback, useEffect, useMemo, useState } from 'react';
import styled from 'styled-components';
import confetti from 'canvas-confetti';
import * as anchor from '@project-serum/anchor';
import {
  Commitment,
  Connection,
  PublicKey,
  Transaction,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import { WalletAdapterNetwork } from '@solana/wallet-adapter-base';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { GatewayProvider } from '@civic/solana-gateway-react';
import Countdown from 'react-countdown';
import { Snackbar, Paper, LinearProgress, Chip } from '@material-ui/core';
import Alert from '@material-ui/lab/Alert';
import { AlertState, getAtaForMint, toDate } from './utils';
import { MintButton } from './MintButton';
import {
  awaitTransactionSignatureConfirmation,
  CANDY_MACHINE_PROGRAM,
  CandyMachineAccount,
  createAccountsForMint,
  getCandyMachineState,
  getCollectionPDA,
  mintOneToken,
  SetupState,
} from './candy-machine';

const cluster = process.env.REACT_APP_SOLANA_NETWORK!.toString();
const decimals = process.env.REACT_APP_SPL_TOKEN_TO_MINT_DECIMALS
  ? +process.env.REACT_APP_SPL_TOKEN_TO_MINT_DECIMALS!.toString()
  : 9;
const splTokenName = process.env.REACT_APP_SPL_TOKEN_TO_MINT_NAME
  ? process.env.REACT_APP_SPL_TOKEN_TO_MINT_NAME.toString()
  : 'TOKEN';

const WalletContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: right;
`;

const WalletAmount = styled.div`
  color: black;
  width: auto;
  padding: 5px 5px 5px 16px;
  min-width: 48px;
  min-height: auto;
  border-radius: 22px;
  background-color: var(--main-text-color);
  box-shadow: 0px 3px 5px -1px rgb(0 0 0 / 20%),
    0px 6px 10px 0px rgb(0 0 0 / 14%), 0px 1px 18px 0px rgb(0 0 0 / 12%);
  box-sizing: border-box;
  transition: background-color 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,
    box-shadow 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms,
    border 250ms cubic-bezier(0.4, 0, 0.2, 1) 0ms;
  font-weight: 500;
  line-height: 1.75;
  text-transform: uppercase;
  border: 0;
  margin: 0;
  display: inline-flex;
  outline: 0;
  position: relative;
  align-items: center;
  user-select: none;
  vertical-align: middle;
  justify-content: flex-start;
  gap: 10px;
`;

const Wallet = styled.ul`
  flex: 0 0 auto;
  margin: 0;
  padding: 0;
`;

const ConnectButton = styled(WalletMultiButton)`
  border-radius: 18px !important;
  padding: 6px 16px;
  background-color: #321649;
  margin: 0 auto;
`;

const NFT = styled(Paper)`
  flex-direction: row;
  margin: 0 auto;
  padding: 20px;
  flex: 1 1 auto;
  background-color: var(--card-background-color) !important;
  box-shadow: 0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22) !important;
`;

const Card = styled(Paper)`
  display: inline-block;
  background-color: var(--countdown-background-color) !important;
  margin: 5px;
  min-width: 40px;
  padding: 24px;

  h1 {
    margin: 0px;
  }
`;

const MintButtonContainer = styled.div`
  margin-top: 16px;
  button.MuiButton-contained:not(.MuiButton-containedPrimary).Mui-disabled {
    color: #464646;
  }

  button.MuiButton-contained:not(.MuiButton-containedPrimary):hover,
  button.MuiButton-contained:not(.MuiButton-containedPrimary):focus {
    -webkit-animation: pulse 1s;
    animation: pulse 1s;
    box-shadow: 0 0 0 2em rgba(255, 255, 255, 0);
  }

  @-webkit-keyframes pulse {
    0% {
      box-shadow: 0 0 0 0 #bf40bf;
    }
  }

  @keyframes pulse {
    0% {
      box-shadow: 0 0 0 0 #bf40bf;
    }
  }
`;

const SolExplorerLink = styled.a`
  color: var(--title-text-color);
  border-bottom: 1px solid var(--title-text-color);
  font-weight: bold;
  list-style-image: none;
  list-style-position: outside;
  list-style-type: none;
  outline: none;
  text-decoration: none;
  text-size-adjust: 100%;

  :hover {
    border-bottom: 2px solid var(--title-text-color);
  }
`;

const MainContainer = styled.div`
  display: flex;
  flex-direction: column;
  margin-top: 20px;
  margin-bottom: 20px;
  margin-right: 4%;
  margin-left: 4%;
  text-align: center;
  justify-content: center;
`;

const MintContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex: 1 1 auto;
  flex-wrap: wrap;
  gap: 20px;
`;

const DesContainer = styled.div`
  display: flex;
  flex-direction: column;
  flex: 1 1 auto;
  gap: 20px;
`;

const Price = styled(Chip)`
  position: absolute;
  margin: 5px;
  font-weight: bold;
  font-size: 1.2em !important;
  font-family: 'Baloo 2', cursive !important;
`;
const Pricetwo = styled.div`
  display: flex;
  flex-direction: row;
  flex: 1 1 auto;
  flex-wrap: wrap;
  gap: 20px;
`;

const Image = styled.img`
  height: 500px;
  width: 90%;
  object-fit: cover;
  border-radius: 7px;
  box-shadow: 5px 5px 40px 5px rgba(0, 0, 0, 0.5);
`;

const BorderLinearProgress = styled(LinearProgress)`
  margin: 20px;
  height: 10px !important;
  border-radius: 30px;
  border: 2px solid white;
  box-shadow: 5px 5px 40px 5px rgba(0, 0, 0, 0.5);
  background-color: var(--main-text-color) !important;

  > div.MuiLinearProgress-barColorPrimary {
    background-color: var(--title-text-color) !important;
  }

  > div.MuiLinearProgress-bar1Determinate {
    border-radius: 30px !important;
    background-image: linear-gradient(
      270deg,
      rgba(255, 255, 255, 0.01),
      rgba(255, 255, 255, 0.5)
    );
  }
`;

export interface HomeProps {
  candyMachineId?: anchor.web3.PublicKey;
  connection: anchor.web3.Connection;
  txTimeout: number;
  rpcHost: string;
  network: WalletAdapterNetwork;
}

const tabData = [
  {
    id: 1,
    name: 'Mint',
  },
  {
    id: 2,
    name: 'Roadmap',
  },
  {
    id: 3,
    name: 'Team',
  },
];

const Home = (props: HomeProps) => {
  const [selectedTab, setSelectedTab] = useState(1);

  const [balance, setBalance] = useState<number>();
  const [isMinting, setIsMinting] = useState(false); // true when user got to press MINT
  const [isActive, setIsActive] = useState(false); // true when countdown completes or whitelisted
  const [solanaExplorerLink, setSolanaExplorerLink] = useState<string>('');
  const [itemsAvailable, setItemsAvailable] = useState(0);
  const [itemsRedeemed, setItemsRedeemed] = useState(0);
  const [itemsRemaining, setItemsRemaining] = useState(0);
  const [isSoldOut, setIsSoldOut] = useState(false);
  const [payWithSplToken, setPayWithSplToken] = useState(false);
  const [price, setPrice] = useState(0);
  const [priceLabel, setPriceLabel] = useState<string>('SOL');
  const [whitelistPrice, setWhitelistPrice] = useState(0);
  const [whitelistEnabled, setWhitelistEnabled] = useState(false);
  const [isBurnToken, setIsBurnToken] = useState(false);
  const [whitelistTokenBalance, setWhitelistTokenBalance] = useState(0);
  const [isEnded, setIsEnded] = useState(false);
  const [endDate, setEndDate] = useState<Date>();
  const [isPresale, setIsPresale] = useState(false);
  const [isWLOnly, setIsWLOnly] = useState(false);

  const [alertState, setAlertState] = useState<AlertState>({
    open: false,
    message: '',
    severity: undefined,
  });

  const [needTxnSplit, setNeedTxnSplit] = useState(true);
  const [setupTxn, setSetupTxn] = useState<SetupState>();

  const wallet = useWallet();
  const [candyMachine, setCandyMachine] = useState<CandyMachineAccount>();

  const rpcUrl = props.rpcHost;
  const solFeesEstimation = 0.012; // approx of account creation fees

  const anchorWallet = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }

    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    } as anchor.Wallet;
  }, [wallet]);

  const refreshCandyMachineState = useCallback(
    async (commitment: Commitment = 'confirmed') => {
      if (!anchorWallet) {
        return;
      }

      const connection = new Connection(props.rpcHost, commitment);

      if (props.candyMachineId) {
        try {
          const cndy = await getCandyMachineState(
            anchorWallet,
            props.candyMachineId,
            connection
          );

          setCandyMachine(cndy);
          setItemsAvailable(cndy.state.itemsAvailable);
          setItemsRemaining(cndy.state.itemsRemaining);
          setItemsRedeemed(cndy.state.itemsRedeemed);

          var divider = 1;
          if (decimals) {
            divider = +('1' + new Array(decimals).join('0').slice() + '0');
          }

          // detect if using spl-token to mint
          if (cndy.state.tokenMint) {
            setPayWithSplToken(true);
            // Customize your SPL-TOKEN Label HERE
            // TODO: get spl-token metadata name
            setPriceLabel(splTokenName);
            setPrice(cndy.state.price.toNumber() / divider);
            setWhitelistPrice(cndy.state.price.toNumber() / divider);
          } else {
            setPrice(cndy.state.price.toNumber() / LAMPORTS_PER_SOL);
            setWhitelistPrice(cndy.state.price.toNumber() / LAMPORTS_PER_SOL);
          }

          // fetch whitelist token balance
          if (cndy.state.whitelistMintSettings) {
            setWhitelistEnabled(true);
            setIsBurnToken(cndy.state.whitelistMintSettings.mode.burnEveryTime);
            setIsPresale(cndy.state.whitelistMintSettings.presale);
            setIsWLOnly(
              !isPresale &&
                cndy.state.whitelistMintSettings.discountPrice === null
            );

            if (
              cndy.state.whitelistMintSettings.discountPrice !== null &&
              cndy.state.whitelistMintSettings.discountPrice !==
                cndy.state.price
            ) {
              if (cndy.state.tokenMint) {
                setWhitelistPrice(
                  cndy.state.whitelistMintSettings.discountPrice?.toNumber() /
                    divider
                );
              } else {
                setWhitelistPrice(
                  cndy.state.whitelistMintSettings.discountPrice?.toNumber() /
                    LAMPORTS_PER_SOL
                );
              }
            }

            let balance = 0;
            try {
              const tokenBalance =
                await props.connection.getTokenAccountBalance(
                  (
                    await getAtaForMint(
                      cndy.state.whitelistMintSettings.mint,
                      anchorWallet.publicKey
                    )
                  )[0]
                );

              balance = tokenBalance?.value?.uiAmount || 0;
            } catch (e) {
              console.error(e);
              balance = 0;
            }
            if (commitment !== 'processed') {
              setWhitelistTokenBalance(balance);
            }
            setIsActive(isPresale && !isEnded && balance > 0);
          } else {
            setWhitelistEnabled(false);
          }

          // end the mint when date is reached
          if (cndy?.state.endSettings?.endSettingType.date) {
            setEndDate(toDate(cndy.state.endSettings.number));
            if (
              cndy.state.endSettings.number.toNumber() <
              new Date().getTime() / 1000
            ) {
              setIsEnded(true);
              setIsActive(false);
            }
          }
          // end the mint when amount is reached
          if (cndy?.state.endSettings?.endSettingType.amount) {
            let limit = Math.min(
              cndy.state.endSettings.number.toNumber(),
              cndy.state.itemsAvailable
            );
            setItemsAvailable(limit);
            if (cndy.state.itemsRedeemed < limit) {
              setItemsRemaining(limit - cndy.state.itemsRedeemed);
            } else {
              setItemsRemaining(0);
              cndy.state.isSoldOut = true;
              setIsEnded(true);
            }
          } else {
            setItemsRemaining(cndy.state.itemsRemaining);
          }

          if (cndy.state.isSoldOut) {
            setIsActive(false);
          }

          const [collectionPDA] = await getCollectionPDA(props.candyMachineId);
          const collectionPDAAccount = await connection.getAccountInfo(
            collectionPDA
          );

          const txnEstimate =
            892 +
            (!!collectionPDAAccount && cndy.state.retainAuthority ? 182 : 0) +
            (cndy.state.tokenMint ? 66 : 0) +
            (cndy.state.whitelistMintSettings ? 34 : 0) +
            (cndy.state.whitelistMintSettings?.mode?.burnEveryTime ? 34 : 0) +
            (cndy.state.gatekeeper ? 33 : 0) +
            (cndy.state.gatekeeper?.expireOnUse ? 66 : 0);

          setNeedTxnSplit(txnEstimate > 1230);
        } catch (e) {
          if (e instanceof Error) {
            if (
              e.message === `Account does not exist ${props.candyMachineId}`
            ) {
              setAlertState({
                open: true,
                message: `Couldn't fetch candy machine state from candy machine with address: ${props.candyMachineId}, using rpc: ${props.rpcHost}! You probably typed the REACT_APP_CANDY_MACHINE_ID value in wrong in your .env file, or you are using the wrong RPC!`,
                severity: 'error',
                hideDuration: null,
              });
            } else if (
              e.message.startsWith('failed to get info about account')
            ) {
              setAlertState({
                open: true,
                message: `Couldn't fetch candy machine state with rpc: ${props.rpcHost}! This probably means you have an issue with the REACT_APP_SOLANA_RPC_HOST value in your .env file, or you are not using a custom RPC!`,
                severity: 'error',
                hideDuration: null,
              });
            }
          } else {
            setAlertState({
              open: true,
              message: `${e}`,
              severity: 'error',
              hideDuration: null,
            });
          }
          console.log(e);
        }
      } else {
        setAlertState({
          open: true,
          message: `Your REACT_APP_CANDY_MACHINE_ID value in the .env file doesn't look right! Make sure you enter it in as plain base-58 address!`,
          severity: 'error',
          hideDuration: null,
        });
      }
    },
    [
      anchorWallet,
      props.candyMachineId,
      props.rpcHost,
      isEnded,
      isPresale,
      props.connection,
    ]
  );

  const renderGoLiveDateCounter = ({ days, hours, minutes, seconds }: any) => {
    return (
      <div>
        <Card elevation={1}>
          <h1>{days}</h1>Days
        </Card>
        <Card elevation={1}>
          <h1>{hours}</h1>
          Hours
        </Card>
        <Card elevation={1}>
          <h1>{minutes}</h1>Mins
        </Card>
        <Card elevation={1}>
          <h1>{seconds}</h1>Secs
        </Card>
      </div>
    );
  };

  const renderEndDateCounter = ({ days, hours, minutes }: any) => {
    let label = '';
    if (days > 0) {
      label += days + ' days ';
    }
    if (hours > 0) {
      label += hours + ' hours ';
    }
    label += minutes + 1 + ' minutes left to MINT.';
    return (
      <div>
        <h3>{label}</h3>
      </div>
    );
  };

  function displaySuccess(mintPublicKey: any, qty: number = 1): void {
    let remaining = itemsRemaining - qty;
    setItemsRemaining(remaining);
    setIsSoldOut(remaining === 0);
    if (isBurnToken && whitelistTokenBalance && whitelistTokenBalance > 0) {
      let balance = whitelistTokenBalance - qty;
      setWhitelistTokenBalance(balance);
      setIsActive(isPresale && !isEnded && balance > 0);
    }
    setSetupTxn(undefined);
    setItemsRedeemed(itemsRedeemed + qty);
    if (!payWithSplToken && balance && balance > 0) {
      setBalance(
        balance -
          (whitelistEnabled ? whitelistPrice : price) * qty -
          solFeesEstimation
      );
    }
    setSolanaExplorerLink(
      cluster === 'devnet' || cluster === 'testnet'
        ? 'https://solscan.io/token/' + mintPublicKey + '?cluster=' + cluster
        : 'https://solscan.io/token/' + mintPublicKey
    );
    setIsMinting(false);
    throwConfetti();
  }

  function throwConfetti(): void {
    confetti({
      particleCount: 400,
      spread: 70,
      origin: { y: 0.6 },
    });
  }

  const onMint = async (
    beforeTransactions: Transaction[] = [],
    afterTransactions: Transaction[] = []
  ) => {
    try {
      if (wallet.connected && candyMachine?.program && wallet.publicKey) {
        setIsMinting(true);
        let setupMint: SetupState | undefined;
        if (needTxnSplit && setupTxn === undefined) {
          setAlertState({
            open: true,
            message: 'Please validate account setup transaction',
            severity: 'info',
          });
          setupMint = await createAccountsForMint(
            candyMachine,
            wallet.publicKey
          );
          let status: any = { err: true };
          if (setupMint.transaction) {
            status = await awaitTransactionSignatureConfirmation(
              setupMint.transaction,
              props.txTimeout,
              props.connection,
              true
            );
          }
          if (status && !status.err) {
            setSetupTxn(setupMint);
            setAlertState({
              open: true,
              message:
                'Setup transaction succeeded! You can now validate mint transaction',
              severity: 'info',
            });
          } else {
            setAlertState({
              open: true,
              message: 'Mint failed! Please try again!',
              severity: 'error',
            });
            return;
          }
        }

        const setupState = setupMint ?? setupTxn;
        const mint = setupState?.mint ?? anchor.web3.Keypair.generate();
        let mintResult = await mintOneToken(
          candyMachine,
          wallet.publicKey,
          mint,
          beforeTransactions,
          afterTransactions,
          setupState
        );

        let status: any = { err: true };
        let metadataStatus = null;
        if (mintResult) {
          status = await awaitTransactionSignatureConfirmation(
            mintResult.mintTxId,
            props.txTimeout,
            props.connection,
            true
          );

          metadataStatus =
            await candyMachine.program.provider.connection.getAccountInfo(
              mintResult.metadataKey,
              'processed'
            );
          console.log('Metadata status: ', !!metadataStatus);
        }

        if (status && !status.err && metadataStatus) {
          setAlertState({
            open: true,
            message: 'Congratulations! Mint succeeded!',
            severity: 'success',
          });

          // update front-end amounts
          displaySuccess(mint.publicKey);
          refreshCandyMachineState('processed');
        } else if (status && !status.err) {
          setAlertState({
            open: true,
            message:
              'Mint likely failed! Anti-bot SOL 0.01 fee potentially charged! Check the explorer to confirm the mint failed and if so, make sure you are eligible to mint before trying again.',
            severity: 'error',
            hideDuration: 8000,
          });
          refreshCandyMachineState();
        } else {
          setAlertState({
            open: true,
            message: 'Mint failed! Please try again!',
            severity: 'error',
          });
          refreshCandyMachineState();
        }
      }
    } catch (error: any) {
      let message = error.msg || 'Minting failed! Please try again!';
      if (!error.msg) {
        if (!error.message) {
          message = 'Transaction Timeout! Please try again.';
        } else if (error.message.indexOf('0x138')) {
        } else if (error.message.indexOf('0x137')) {
          message = `SOLD OUT!`;
        } else if (error.message.indexOf('0x135')) {
          message = `Insufficient funds to mint. Please fund your wallet.`;
        }
      } else {
        if (error.code === 311) {
          message = `SOLD OUT!`;
        } else if (error.code === 312) {
          message = `Minting period hasn't started yet.`;
        }
      }

      setAlertState({
        open: true,
        message,
        severity: 'error',
      });
    } finally {
      setIsMinting(false);
    }
  };

  useEffect(() => {
    (async () => {
      if (anchorWallet) {
        const balance = await props.connection.getBalance(
          anchorWallet!.publicKey
        );
        setBalance(balance / LAMPORTS_PER_SOL);
      }
    })();
  }, [anchorWallet, props.connection]);

  useEffect(() => {
    refreshCandyMachineState();
  }, [
    anchorWallet,
    props.candyMachineId,
    props.connection,
    isEnded,
    isPresale,
    refreshCandyMachineState,
  ]);

  return (
    <main>
      <MainContainer>
        <br />
        <MintContainer>
          <DesContainer>
            <NFT elevation={3}>
              {/* <br /> */}
              <div id="innerContainer">
                <div id="left">
                  <div style={{ margin: 0, padding: 0 }}>
                    <Price
                      label={
                        isActive &&
                        whitelistEnabled &&
                        whitelistTokenBalance > 0
                          ? whitelistPrice + ' ' + priceLabel
                          : price + ' ' + priceLabel
                      }
                    />
                    <Image src="tmr.gif" alt="NFT To Mint" />
                  </div>
                  {/* <h2>Konkord Partner</h2> */}

                  <div className="leftFooter">
                    <div className="lfooterLeft">
                      <h3>The Meka Race</h3>
                      <span className="lfooterlinks">DOXXED</span>
                      <span className="lfooterlinks">ESCROW 24HR</span>
                      {/* <span className="lfooterlinks">Twitter</span>
                      <span className="lfooterlinks">Discord</span> */}
                    </div>
                    <div className="lfooterRight">
                      <p>Total Supply: 4444</p>
                      <p>Price: 0.8 SOL</p>
                    </div>
                  </div>

                
                </div>
                <div id="right">
                  <div className="tabContainer">
                    <div className="tabcontbuttons">
                      <div className="contbtn">
                        Solana Network: <span>3,988 TPS</span>
                      </div>
                      <div className="contbtn">
                        <WalletContainer>
                          <Wallet>
                            {wallet ? (
                              <WalletAmount>
                                {(balance || 0).toLocaleString()} SOL
                                <ConnectButton />
                              </WalletAmount>
                            ) : (
                              <ConnectButton>Connect Wallet</ConnectButton>
                            )}
                          </Wallet>
                        </WalletContainer>
                      </div>
                    </div>
                    <div className="tabs">
                      {tabData.map((tab) => (
                        <div
                          key={tab.id}
                          onClick={() => setSelectedTab(tab.id)}
                          className={`tab ${
                            selectedTab === tab.id && 'active'
                          }`}
                        >
                          {tab.name}
                        </div>
                      ))}
                    </div>

                    <div
                      className="tabcontents"
                      style={{ borderRadius: selectedTab !== 1 ? '4px' : '' }}
                    >
                      {selectedTab === 1 && (
                        <>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">OG</span>
                              <span
                                className="contentStatus"
                                style={{
                                  color: 'rgb(160, 160, 255)',
                                }}
                              >
                                Done
                              </span>
                            </div>

                            {/* <small className="contentitem">
                              <span>Count : </span>
                              2356
                            </small> */}
                            <small className="contentitem">
                              <span>Limit : </span>8
                            </small>
                            <small className="contentitem">
                              <span>Price : </span>
                              0.6 SOL
                            </small>
                          </div>

                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Whitelist</span>
                              <span
                                className="contentStatus"
                                style={{
                                  color: 'rgb(160, 160, 255)',
                                }}
                              >
                                Live
                              </span>
                            </div>

                            <small className="contentitem">
                              <span>Limit : </span>8
                            </small>
                            <small className="contentitem">
                              <span>Price : </span>
                              0.7 SOL
                            </small>
                          </div>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Public</span>
                              <span
                                className="contentStatus"
                                style={{
                                  color: 'rgb(160, 160, 255)',
                                }}
                              >
                                Live
                              </span>
                            </div>

                            <small className="contentitem">
                              <span>Limit : </span>8
                            </small>
                            <small className="contentitem">
                              <span>Price : </span>
                              0.8 SOL
                            </small>
                          </div>
                        </>
                      )}
                      {selectedTab === 2 && (
                        <div style={{ paddingBottom: '80px' }}>
                          <div className="tabcontent">
                            <img src="roadmap.jpg" width="580" height="372"></img>
                          </div>
                        </div>
                      )}
                      {selectedTab === 3 && (
                        <div style={{ paddingBottom: '80px' }}>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">
                                Tardo: Founder
                              </span>
                              <a
                                href="https://twitter.com/TardoTMR"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                              The founder of The Meka Race. The face of the brand. The leader and head marketer. Building day after day to bring his holders value. Starting in crypto in 2020 fairly young hes built a personal brand that has bridged over to The Meka Race.
                            </small>
                          </div>

                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Aaron: Co-Founder</span>
                              <a
                                href="https://twitter.com/Aaron_TMR"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                             Aaron, the young mind of the group, but the most strict. Aaron and Tardo are a package deal when it comes to The Meka Race. Meeting together, building together, and learning together to bring their amazing holders the most enjoyable experience.
                            </small>
                          </div>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Lucky Loser: Artist</span>
                              <a
                                href="https://twitter.com/#"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                              The visual illustrator of The Meka Race. This being his first project came with a great learning experience and drawing some dope shit! With years of art under his belt since the age of 7 briding it over to NFTs was a fun experiment gone right!
                            </small>
                          </div>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Yeet: Developer</span>
                              <a
                                href="https://twitter.com/yung_yeeet"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                              The Konkord.me lead developer. Working the back end to create something amazing for the front end.  
                            </small>
                          </div>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Task: Advisor</span>
                              <a
                                href="https://twitter.com/Always_Oblak"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                              A well-known figure in the Solana Space. He has advised a variety of projects on minting in different market conditions including Ghost Kid DAO. Networking & outreach is his specialty. Having the ability to adapt quickly in these market conditions & provide real value to the Solana Ecosystem is what makes Task such a good team player.
                            </small>
                          </div>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Bongus: Advisor</span>
                              <a
                                href="https://twitter.com/bongus_sol"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                              Embedded in web3 with two Solana-based projects founded under his belt. A creative jack of all trades in and out of the space
                            </small>
                          </div>
                          <div className="tabcontent">
                            <div className="contentHeader">
                              <span className="contentTitle">Metalark: Head-Mod</span>
                              <a
                                href="https://twitter.com/Metalark42"
                                className="contentStatus"
                                style={{
                                  color: "rgb(160, 160, 255)",
                                  textDecoration: "none",
                                }}
                              >
                                Twitter
                              </a>
                            </div>

                            <small>
                              Or Meta, or Lark, or Hey you!!! I got into NFT through my love of Video Games. Was looking for a new game on ETH or Polygon to play and came across games on Solana. Decided to try it out and here I am. I love learning things and doing research. If you ask me a question and I don`t know the answer, I will find it lol.
                            </small>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="tabfooter">
                      <div className="footerContent">
                        <div className="footertop">
                          <span>
                            ({itemsRedeemed}/{itemsAvailable}) Minted
                          </span>
                          <div className="mintbtn">
                            <MintButtonContainer>
                              {!isActive &&
                              !isEnded &&
                              candyMachine?.state.goLiveDate &&
                              (!isWLOnly || whitelistTokenBalance > 0) ? (
                                <Countdown
                                date={toDate(candyMachine?.state.goLiveDate)}
                                onMount={({ completed }) =>
                                  completed && setIsActive(!isEnded)
                                }
                                onComplete={() => {
                                  setIsActive(!isEnded);
                                }}
                                // renderer={renderGoLiveDateCounter}
                                />
                              ) : !wallet ? (
                                <ConnectButton>Connect Wallet</ConnectButton>
                              ) : !isWLOnly || whitelistTokenBalance > 0 ? (
                                candyMachine?.state.gatekeeper &&
                                wallet.publicKey &&
                                wallet.signTransaction ? (
                                  <GatewayProvider
                                    wallet={{
                                      publicKey:
                                        wallet.publicKey ||
                                        new PublicKey(CANDY_MACHINE_PROGRAM),
                                      //@ts-ignore
                                      signTransaction: wallet.signTransaction,
                                    }}
                                    // // Replace with following when added
                                    // gatekeeperNetwork={candyMachine.state.gatekeeper_network}
                                    gatekeeperNetwork={
                                      candyMachine?.state?.gatekeeper
                                        ?.gatekeeperNetwork
                                    } // This is the ignite (captcha) network
                                    /// Don't need this for mainnet
                                    clusterUrl={rpcUrl}
                                    cluster={cluster}
                                    options={{ autoShowModal: false }}
                                  >
                                    <MintButton
                                      candyMachine={candyMachine}
                                      isMinting={isMinting}
                                      isActive={isActive}
                                      isEnded={isEnded}
                                      isSoldOut={isSoldOut}
                                      onMint={onMint}
                                    />
                                  </GatewayProvider>
                                ) : (
                                  <MintButton
                                    candyMachine={candyMachine}
                                    isMinting={isMinting}
                                    isActive={isActive}
                                    isEnded={isEnded}
                                    isSoldOut={isSoldOut}
                                    onMint={onMint}
                                  />
                                )
                              ) : (
                                <h1>Mint is private.</h1>
                              )}
                            </MintButtonContainer>
                          </div>
                        </div>
                        <div className="remaining">
                          {itemsRemaining} Remaining{' '}
                        </div>
                        <LinearProgress
                          variant="buffer"
                          value={100 - (itemsRemaining * 100) / itemsAvailable}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* connecting button */}

              {/* {wallet && isActive && solanaExplorerLink && (
                <SolExplorerLink href={solanaExplorerLink} target="_blank">
                  View on Solscan
                </SolExplorerLink>
              )} */}
            </NFT>
          </DesContainer>
        </MintContainer>
      </MainContainer>
      <Snackbar
        open={alertState.open}
        autoHideDuration={6000}
        onClose={() => setAlertState({ ...alertState, open: false })}
      >
        <Alert
          onClose={() => setAlertState({ ...alertState, open: false })}
          severity={alertState.severity}
        >
          {alertState.message}
        </Alert>
      </Snackbar>
    </main>
  );
};

export default Home;
